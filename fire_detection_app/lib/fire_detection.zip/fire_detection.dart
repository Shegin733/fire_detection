import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/io.dart';

import 'package:assets_audio_player/assets_audio_player.dart';

class FireDetectionScreen extends StatefulWidget {
  const FireDetectionScreen({Key? key}) : super(key: key);

  @override
  State<FireDetectionScreen> createState() => _FireDetectionScreenState();
}

class _FireDetectionScreenState extends State<FireDetectionScreen> {
  bool startDetection = false;
  String temperature = '';
  String smoke = '';
  Timer? timer;
  late AudioPlayer audioPlayer;
  WebSocketChannel? channel;

  @override
  void initState() {
    super.initState();
    fetchData();
    startDataUpdateTimer();
  }



  void startDataUpdateTimer() {
    const updateInterval = Duration(milliseconds: 500);
    timer = Timer.periodic(updateInterval, (_) {
      fetchData();
    });
  }

  Future<void> fetchData() async {
    final response = await http.get(
      Uri.parse(
          'https://api.thingspeak.com/channels/2145528/feeds.json?api_key=SSDJ3RBYOYCSFSFK&results=1'),
    );

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      if (json['feeds'] != null && json['feeds'].isNotEmpty) {
        setState(() {
          temperature = json['feeds'][0]['field1'].toString();
          smoke = json['feeds'][0]['field2'].toString();
        });
        final smokeValue = double.tryParse(smoke);
        if (smokeValue != null && smokeValue > 100.0) {
          showAlertMessage('Smoke Detected');
          playAlarmSound();
        }
      } else {
        setState(() {
          temperature = 'No data available';
          smoke = 'No data available';
        });
      }
    } else {
      setState(() {
        temperature = 'Error';
        smoke = 'Error';
      });
    }
  }

  void showAlertMessage(String message) async {
    final detStatus = 'Fire Detected';
    final showAlertMessage = true;

    if (detStatus == "Fire Detected" && showAlertMessage) {
      setState(() {
        smoke = 'Smoke Detected: $smoke';
      });

      // Send a message to the ESP32

    }
  }

  void playAlarmSound() async {
    final player = AudioPlayer();

    await player.play(AssetSource('alarm.wav'));
  }

  Future<void> startFireDetection() async {
    final response =
    await http.post(Uri.parse('http://localhost:8000/start_detection'));

    if (response.statusCode == 200) {
      setState(() {
        startDetection = true;
      });
      print('Fire detection started');
      channel = WebSocketChannel.connect(Uri.parse('ws://localhost:8000/'));
    } else {
      print('Failed to start fire detection');
    }
  }

  Future<void> stopFireDetection() async {
    final response =
    await http.post(Uri.parse('http://localhost:8000/stop_detection'));
    if (response.statusCode == 200) {
      setState(() {
        startDetection = false;
      });
      channel?.sink.close();
      print('Fire detection stopped');
    } else {
      print('Failed to stop fire detection');
    }
  }
  @override
  void dispose() {
    timer?.cancel();
    channel?.sink.close();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fire Detection App'),
      ),
      body: Center(


        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            Text('Temperature: $temperature'),
            const SizedBox(height: 16.0),
            Text('Smoke: $smoke'),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: startFireDetection,
              child: const Text('Start Fire Detection'),
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: stopFireDetection,
              child: const Text('Stop Fire Detection'),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: StreamBuilder(
                  stream: channel?.stream,
                  builder: (context, snapshot) {
                    if (snapshot.hasData) {
                      final jsonRes = jsonDecode(snapshot.data.toString());
                      final response = jsonRes["response"];
                      final frame = base64Decode(jsonRes['frame']);
                      String detStatus = response["detection"] as bool
                          ? "Fire Detected"
                          : "No Fire Detected";
                      String detDesc = response["desc"];
                      DateTime detTimestamp =
                      DateTime.parse(response["timestamp"]);
                      return Column(
                        children: [
                          Text("Status : $detStatus"),
                          Text("Desc : $detDesc"),
                          Text("TimeStamp : $detTimestamp"),
                          Image.memory(frame),
                        ],
                      );
                    } else {
                      return const Text(
                        "No detection response received from server",
                      );
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}


